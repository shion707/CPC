clear; close all; clc;

%% Exp 1
load('Exp1')

figure; 

subplot(3,2,1);hold on;
averag=nanmean(hand_common_bin_angle,2);
se=[nanstd(hand_common_bin_angle')./sqrt(subnum)];
 
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.2 0.5 1],'EdgeColor','none','FaceAlpha',0.2)
plot(averag,'-','color',[0.2 0.5 1],'markerfacecolor',[0.2 0.5 1],'markeredgecolor','none','linewidth',2)

axis([0 180 -5 25])
%set(gca, 'LineWidth',2);
set(gca,'xtick',[20:50:500]); 
%set(gca,'xticklabel',[40:40:500]-20,'fontsize',10);
set(gca,'ytick',[0:20:30]);
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off

title('Exp1')
plot([20 20],[-100 100],'k--')
plot([121 121],[-100 100],'k--')

%% Exp 2
clear;
load('Exp2')

subnum=30;
figure; 
subplot(2,2,1);hold on;
hand_common_bin_angle=removeoutlier(hand_common_bin_angle,2.5);
nn=260;
averag=nanmean(hand_common_bin_angle(1:nn,:),2);

se=[nanstd(hand_common_bin_angle(1:nn,:)')./sqrt(subnum)];

fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.5 0.5 1],'EdgeColor','none','FaceAlpha',0.2)
plot(averag,'-','color',[0.5 0.5 1],'markerfacecolor',[1 0.3 0.4],'markeredgecolor','none','linewidth',2)

axis([-10 270 -30 30])
set(gca,'xtick',[10:110:260]);
% set(gca,'xticklabel',[0:20:80]*2,'fontsize',15);
set(gca,'ytick',[-20:20:20]);

title('Exp2')

subplot(2,2,2);hold on;
averag=nanmean(hand_common_bin_angle(21:120,:),2);

se=[nanstd(hand_common_bin_angle(21:120,:)')./sqrt(subnum)];

fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.1  0.6 0.4],'EdgeColor','none','FaceAlpha',0.2)
plot(averag,'-','color',[0.1  0.6 0.4],'markerfacecolor',[0.1 0.6 0.4],'markeredgecolor','none','linewidth',2)


averag=-nanmean(hand_common_bin_angle(133:233,:),2);

se=[nanstd(hand_common_bin_angle(133:233,:)')./sqrt(subnum)];

fill([1:length(se) length(se):-1:1]+1,[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.3 0.9 0.5],'EdgeColor','none','FaceAlpha',0.2)
plot([1:length(se)]+1,averag,'-','color',[0.3 0.9 0.5],'markerfacecolor',[0.3 0.9 0.5],'markeredgecolor','none','linewidth',2)

axis([-10 110 -10 30])
set(gca,'xtick',[0:100:800]);
set(gca,'ytick',[-30:10:30]);

l1=nanmean(hand_common_bin_angle(31:120,:),1);
l2=nanmean(hand_common_bin_angle(171:260,:),1);


%% Exp 3
clear;
load('Exp3')

figure; 
subplot(2,2,1);hold on;
averag=nanmean(hand_common_bin_angle(21:120+14,:),2);

se=[nanstd(hand_common_bin_angle(21:120+14,:)')./sqrt(subnum)];

fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.1  0.6 0.4],'EdgeColor','none','FaceAlpha',0.2)
plot(averag,'-','color',[0.1  0.6 0.4],'markerfacecolor',[0.1 0.6 0.4],'markeredgecolor','none','linewidth',2)
se=[nanstd(hand_common_bin_angle(120+16:120+40,:)')./sqrt(subnum)];

averag=nanmean(hand_common_bin_angle(120+16:120+40,:),2);


fill([1:length(se) length(se):-1:1]+115,[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.1  0.6 0.4],'EdgeColor','none','FaceAlpha',0.2)
plot([1:length(se)]+115,averag,'-','color',[0.1  0.6 0.4],'markerfacecolor',[0.1 0.6 0.4],'markeredgecolor','none','linewidth',2)


averag=nanmean(hand_common_bin_angle(160:260,:),2);

se=[nanstd(hand_common_bin_angle(160:260,:)')./sqrt(subnum)];

fill([1:length(se) length(se):-1:1]+1,[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.3 0.9 0.5],'EdgeColor','none','FaceAlpha',0.2)
plot([1:length(se)]+1,averag,'-','color',[0.3 0.9 0.5],'markerfacecolor',[0.3 0.9 0.5],'markeredgecolor','none','linewidth',2)

axis([-10 160 -10 30])
set(gca, 'LineWidth',1);
set(gca,'xtick',[0:50:800]);
% set(gca,'xticklabel',[0:20:80]*2,'fontsize',15);
set(gca,'ytick',[-0:10:30]);
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off
title('Exp3')

%% Exp 4
clear
load('Exp4')

figure; 
subplot(2,2,1);hold on;

plot(nanmean(l1_01'),'-','color',[1 0.5 1],'markerfacecolor',[1 0.3 0.4],'markeredgecolor','none','linewidth',2)
plot(nanmean(l2_01'),'-','color',[1 0.5 1],'markerfacecolor',[1 0.3 0.4],'markeredgecolor','none','linewidth',2)
title('Exp4 p=0.9')


subplot(2,2,2);hold on;

plot(nanmean(l1_05'),'-','color',[1 0.5 1],'markerfacecolor',[1 0.3 0.4],'markeredgecolor','none','linewidth',2)
plot(nanmean(l2_05'),'-','color',[1 0.5 1],'markerfacecolor',[1 0.3 0.4],'markeredgecolor','none','linewidth',2)
title('Exp4 p=0.5')

subplot(2,2,3);hold on;

plot(nanmean(l1_08'),'-','color',[1 0.5 1],'markerfacecolor',[1 0.3 0.4],'markeredgecolor','none','linewidth',2)
plot(nanmean(l2_08'),'-','color',[1 0.5 1],'markerfacecolor',[1 0.3 0.4],'markeredgecolor','none','linewidth',2)
title('Exp4 p=0.125')

%% Exp 5
clear
load('Exp5')
subnum=70;

figure; subplot(2,2,1);hold on;
%plot(abdhand)
averag=nanmean(abdhand);
averag=[0 averag];
plot(0:67,averag,'-','color',[0.8 0.3 0.4],'markerfacecolor',[0.2 0.3 0.4],'markeredgecolor','none','linewidth',3)

se=[0 nanstd(abdhand)./sqrt(subnum)];
fill([0:67 67:-1:0],[averag+se averag(end:-1:1)-se(end:-1:1)],[0.8 0.3 0.4],'EdgeColor','none','FaceAlpha',0.2)

axis([-5 73 -0.6 3.4])
set(gca,'xtick',[0:20:80]);
set(gca,'xticklabel',[0:20:80]*2,'fontsize',15);
set(gca,'ytick',[0:1:3]);
hand1=nanmean(abdhand);
title('Exp5')

%% Exp 6
clear
load('Exp6')


figure

subplot(3,2,1);hold on;
averag=nanmean(hand_common_bin_angle,2);
se=[nanstd(hand_common_bin_angle')./sqrt(subnum)];
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[0.7 0.5 1],'EdgeColor','none','FaceAlpha',0.2)
plot(averag,'-','color',[0.7 0.5 1],'markerfacecolor',[0.7 0.5 1],'markeredgecolor','none','linewidth',2)

plot([110 110],[-100 100],'k--')
plot([10 10],[-100 100],'k--')

axis([0 170 -5 25])
% set(gca, 'LineWidth',1);
set(gca,'xtick',[10:50:800]);
% set(gca,'xticklabel',[0:20:80]*2,'fontsize',15);
set(gca,'ytick',[0:20:30]);
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off

title('Exp6')

%% Exp 7
clear
load('Exp7')
load('Exp7_c')

figure
subplot(2,2,1);hold on;
h=(nanmean(one_back));
bar(nanmean(h'),'facealpha',0.1,'facecolor',[0.5 0.3 1],'linewidth',2,'edgecolor',[0.5 0.3 1])
lineerrorbar('x',1,'y',nanmean(h'),'std',nanstd(h')./sqrt(38),'subnum',1,'color',[0.5 0.3 1],'width',2)

h=nanmean(abdhand);
bar(2,nanmean(h'),'facealpha',0.1,'facecolor',[1 0.5 0.5],'linewidth',2,'edgecolor',[1 0.5 0.5])
lineerrorbar('x',2,'y',nanmean(h'),'std',nanstd(h')./sqrt(38),'subnum',1,'color',[1 0.5 0.5],'width',2)
%scatter(0*h+1+0.2*randn(1,subnum),h,50,'markerfacecolor',[0.5 0.5 0.5],'markerfacealpha',0.5,'markeredgecolor','none')
set(gca,'xtick',[]);
axis([0 4 0 4])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off

title('Exp7')


%% Exp 8
clear
load('Exp8_long')

subnum=26;

c=[0.5 0.8 0.7];

figure(123); subplot(2,2,1);hold on;
block1=30:190;
averag=nanmean(hand_common_bin_angle(block1,:),2);
se=[nanstd(hand_common_bin_angle(block1,:)')./sqrt(subnum)];
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],c,'EdgeColor','none','FaceAlpha',0.2)
plot(averag,'-','color',c,'markerfacecolor',c,'markeredgecolor','none','linewidth',2)


axis([-10 170 -5 35])
set(gca, 'LineWidth',1);
set(gca,'xtick',[0:50:800]);
set(gca,'ytick',[-30:10:30]);
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off

title('Exp 8')



earlyR=hand_common_bin_angle(160:190,:)./hand_common_bin_angle(141:171,:);
earlyR=removeoutlier(earlyR,2.5);
earlyR=nanmean(power(earlyR,1/20));
h=earlyR;
subplot(2,2,2);hold on;
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})

bar(nanmean(h'),'facealpha',0.1,'facecolor',c,'linewidth',2,'edgecolor',c)
lineerrorbar('x',1,'y',nanmean(h'),'std',nanstd(h')./sqrt(26),'subnum',1,'color',c,'width',2)


earlyR=nanmean(hand_common_bin_angle(131:140,:))./nanmean(hand_common_bin_angle(120:130,:));
earlyR=removeoutlier(earlyR,2.5);
earlyR=(power(earlyR,1/5));
h=earlyR;

subplot(2,2,3);hold on;
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
bar(nanmean(h'),'facealpha',0.1,'facecolor',c,'linewidth',2,'edgecolor',c)
lineerrorbar('x',1,'y',nanmean(h'),'std',nanstd(h')./sqrt(26),'subnum',1,'color',c,'width',2)



load('Exp8_0')
c=[1 0.5 1];
subnum=25;

figure(123); subplot(2,2,1);hold on;
block1=30:190;
averag=nanmean(hand_common_bin_angle(block1,:),2);
se=[nanstd(hand_common_bin_angle(block1,:)')./sqrt(subnum)];
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],c,'EdgeColor','none','FaceAlpha',0.2)
plot(averag,'-','color',c,'markerfacecolor',c,'markeredgecolor','none','linewidth',2)


axis([-10 170 -5 35])
set(gca, 'LineWidth',1);
set(gca,'xtick',[0:50:800]);
set(gca,'ytick',[-30:10:30]);
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off




earlyR=nanmean(hand_common_bin_angle(160:190,:))./nanmean(hand_common_bin_angle(141:171,:));
earlyR(earlyR<0)=nan;
earlyR=(power(earlyR,1/20));
h=earlyR;
subplot(2,2,2);hold on;
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})

bar(2,nanmean(h'),'facealpha',0.1,'facecolor',c,'linewidth',2,'edgecolor',c)
lineerrorbar('x',2,'y',nanmean(h'),'std',nanstd(h')./sqrt(26),'subnum',1,'color',c,'width',2)
axis([0 7 0.85 1.05])
set(gca, 'LineWidth',1);
set(gca,'xtick',[]);
set(gca,'ytick',[-0.5:0.05:1]);
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off
title('lateRetention')


earlyR=nanmean(hand_common_bin_angle(131:140,:))./nanmean(hand_common_bin_angle(120:130,:));
earlyR(earlyR<0)=nan;
earlyR=(power(earlyR,1/5));
earlyR=removeoutlier(earlyR,2.5);
h=earlyR;

subplot(2,2,3);hold on;
bar(2, nanmean(h'),'facealpha',0.1,'facecolor',c,'linewidth',2,'edgecolor',c)
lineerrorbar('x',2,'y',nanmean(h'),'std',nanstd(h')./sqrt(26),'subnum',1,'color',c,'width',2)

axis([0 7 0.85 1.05])
set(gca, 'LineWidth',1);
set(gca,'xtick',[]);
% set(gca,'xticklabel',[0:20:80]*2,'fontsize',15);
set(gca,'ytick',[-0.5:0.05:1]);
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',1);
box off
title('earlyRetention')